.pragma library

