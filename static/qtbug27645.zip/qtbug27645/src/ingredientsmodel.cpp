#include "ingredientsmodel.h"

#include <QtQml>

#include "helpers.h"

namespace
{
    void initQml()
    {
        qmlRegisterSingletonType< IngredientsModel >(
            "BottlingPlant.Models",
            1, 0,
            "Ingredients",
            [](QQmlEngine*, QJSEngine*) -> QObject*
            {
                return new IngredientsModel();
            }
        );
    }

    Q_CONSTRUCTOR_FUNCTION(initQml)
}

IngredientsModel::IngredientsModel(QObject* parent)
    : QQmlObjectListModel< IngredientsItem >(parent, "name", "oid")
{
    populate("en");
}

IngredientsModel::~IngredientsModel()
{

}

void IngredientsModel::populate(const QString& locale)
{
    clear();

    BottlingPlant::populateModel< IngredientsItem >(
        this,
        "data/ingredients.json",
        [](const QJsonObject& object, QString* errorString)
        {
            QStringList errors;

            QString dictErrorString;

            if (!BottlingPlant::dictionaryValidator< QJsonValue::Double >(object, &dictErrorString))
                errors.push_back(dictErrorString);

            BottlingPlant::validateObjectField< QJsonValue::Double >(object, "unitId", &errors);
            BottlingPlant::validateObjectField< QJsonValue::Double >(object, "quantity", &errors);
            BottlingPlant::validateObjectField< QJsonValue::Double >(object, "maxQuantity", &errors);

            if (errorString != nullptr)
                *errorString = errors.join(", ");

            return errors.size() == 0;
        },

        [locale](const QJsonObject& object)
        {
            return new IngredientsItem(
                        object.value("id").toInt(),
                        BottlingPlant::extractLocalizableString(object.value("name"), locale),
                        object.value("unitId").toInt(),
                        object.value("quantity").toDouble(),
                        object.value("maxQuantity").toDouble());
        }
    );
}
