#include "helpers.h"

namespace BottlingPlant
{
    QString extractLocalizableString(const QJsonValue& value, const QString& locale)
    {
       return value.isObject()?
                   value.toObject().value(locale).toString():
                   value.toString();
    }

    QString jsonTypeToString(QJsonValue::Type type)
    {
        switch (type)
        {
            case QJsonValue::Bool: return "bool";
            case QJsonValue::Double: return "double";
            case QJsonValue::String: return "string";
            case QJsonValue::Array: return "array";
            case QJsonValue::Object: return "object";
            default:
                ;
        }

        return "undefined";
    }

    bool validateLocalizableString(const QJsonValue& value, QString* errorString)
    {
        QStringList errors;

        if (!value.isString() && !value.isObject())
            errors.push_back("localizable string must be Object or String");

        if (errorString != nullptr)
            *errorString = errors.join(", ");

        return errors.size() == 0;
    }
}
