#ifndef RECIPESITEM_H
#define RECIPESITEM_H

#include <QObject>

#include "qqmlhelpers.h"
#include "qqmlobjectlistmodel.h"

#include "recipeingredientsitem.h"

class RecipesItem : public QObject
{
    Q_OBJECT

    QML_READONLY_PROPERTY(int, beverageId)
    QML_OBJMODEL_PROPERTY(RecipeIngredientsItem, ingredients)

public:
    RecipesItem(int beverageId, QObject* parent = nullptr)
        : QObject(parent),
          m_beverageId{beverageId},
          m_ingredients{new QQmlObjectListModel< RecipeIngredientsItem >(this)}
    {
    }

    virtual ~RecipesItem()
    {
    }

};

#endif // RECIPESITEM_H
