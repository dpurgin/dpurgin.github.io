#include "pieindicator.h"
#include <QPainter>
#include <QBrush>
#include <QtQuick>

namespace
{
    void initQml()
    {
        qmlRegisterType<PieIndicator>(
                    "at.sequality.setouch3.components", 1, 0, "PieIndicator");
    }

    Q_CONSTRUCTOR_FUNCTION(initQml)
}

PieIndicator::PieIndicator(QQuickItem *parent) : QQuickPaintedItem (parent), m_loadingAngle(0), m_discWidth(0)
{

}

int PieIndicator::loadingAngle() const
{
    return m_loadingAngle;
}

int PieIndicator::discWidth() const
{
    return m_discWidth;
}

QColor PieIndicator::colorBegin() const
{
    return m_colorBegin;
}

QColor PieIndicator::colorEnd() const
{
    return m_colorEnd;
}

void PieIndicator::setLoadingAngle(int loadingAngle)
{
    if (m_loadingAngle == loadingAngle)
        return;

    m_loadingAngle = loadingAngle;
    emit loadingAngleChanged(loadingAngle);
    update();
}

void PieIndicator::setDiscWidth(int discWidth)
{
    if (m_discWidth == discWidth)
        return;

    m_discWidth = discWidth;
    emit discWidthChanged(discWidth);
    update();
}

void PieIndicator::setColorBegin(QColor colorBegin)
{
    if (m_colorBegin == colorBegin)
        return;

    m_colorBegin = colorBegin;
    emit colorBeginChanged(colorBegin);
}

void PieIndicator::setColorEnd(QColor colorEnd)
{
    if (m_colorEnd == colorEnd)
        return;

    m_colorEnd = colorEnd;
    emit colorEndChanged(colorEnd);
}

void PieIndicator::paint(QPainter *painter)
{
    QRect drawingRect;

    drawingRect.setX(m_discWidth/2);
    drawingRect.setY(m_discWidth/2);

    drawingRect.setWidth(int(width()) - m_discWidth);
    drawingRect.setHeight(int(height()) - m_discWidth);

    painter->setRenderHint(QPainter::Antialiasing);

    QConicalGradient gradient;
    gradient.setCenter(drawingRect.center());
    gradient.setAngle(90);
    gradient.setColorAt(0, m_colorBegin);
    gradient.setColorAt(1, m_colorEnd);

    //create pen from gradient
    QPen pen(QBrush(gradient), m_discWidth);
    pen.setCapStyle(Qt::FlatCap);

    painter->setPen(pen);
    painter->drawArc(drawingRect, 90 * 16, -m_loadingAngle * 16);
}
