#ifndef PIEINDICATORNATIVE_H
#define PIEINDICATORNATIVE_H

#include <QQuickPaintedItem>

class PieIndicator : public QQuickPaintedItem
{
    Q_OBJECT
    Q_PROPERTY(int loadingAngle READ loadingAngle WRITE setLoadingAngle NOTIFY loadingAngleChanged)
    Q_PROPERTY(int discWidth READ discWidth WRITE setDiscWidth NOTIFY discWidthChanged)
    Q_PROPERTY(QColor colorBegin READ colorBegin WRITE setColorBegin NOTIFY colorBeginChanged)
    Q_PROPERTY(QColor colorEnd READ colorEnd WRITE setColorEnd NOTIFY colorEndChanged)

public:
    explicit PieIndicator(QQuickItem *parent = 0);
    int loadingAngle() const;
    int discWidth() const;
    QColor colorBegin() const;
    QColor colorEnd() const;

public slots:
    void setLoadingAngle(int loadingAngle);
    void setDiscWidth(int discWidth);
    void setColorBegin(QColor colorBegin);
    void setColorEnd(QColor colorEnd);

signals:
    void loadingAngleChanged(int loadingAngle);
    void discWidthChanged(int discWidth);
    void colorBeginChanged(QColor colorBegin);
    void colorEndChanged(QColor colorEnd);

private:
    void paint(QPainter *painter);
    int m_loadingAngle;
    int m_discWidth;
    QColor m_colorBegin;
    QColor m_colorEnd;
};

#endif // PIEINDICATORNATIVE_H
