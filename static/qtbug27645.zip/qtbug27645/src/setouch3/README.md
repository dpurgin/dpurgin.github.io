C++ components of setouch3 are located here. Register metatypes using a constructor function 
in .cpp file:

```c++
// mycustomtype.cpp

namespace 
{
    void initQml()
    {
        qmlRegisterType< MyCustomType >("at.sequality.setouch3", 1, 0, "MyCustomType");
    }
    
    Q_CONSTRUCTOR_FUNCTION(initQml)
}
```