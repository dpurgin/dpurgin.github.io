#ifndef TEMPERATURESCALE_H
#define TEMPERATURESCALE_H

#include <QQuickPaintedItem>

class TemperatureScale : public QQuickPaintedItem
{
    Q_OBJECT
    Q_PROPERTY(int topWidth READ topWidth WRITE setTopWidth NOTIFY topWidthChanged)
    Q_PROPERTY(QColor backgroundColor READ backgroundColor WRITE setBackgroundColor NOTIFY backgroundColorChanged)
    Q_PROPERTY(QColor color READ color WRITE setColor NOTIFY colorChanged)
    Q_PROPERTY(int minimumValue READ minimumValue WRITE setMinimumValue NOTIFY minimumValueChanged)
    Q_PROPERTY(int maximumValue READ maximumValue WRITE setMaximumValue NOTIFY maximumValueChanged)
    Q_PROPERTY(int currentValue READ currentValue WRITE setCurrentValue NOTIFY currentValueChanged)

public:
    explicit TemperatureScale(QQuickItem *parent = 0);
    int topWidth() const;
    QColor backgroundColor() const;
    QColor color() const;
    int minimumValue() const;
    int maximumValue() const;
    int currentValue() const;

public slots:
    void setTopWidth(int topWidth);
    void setBackgroundColor(QColor backgroundColor);
    void setColor(QColor color);
    void setMinimumValue(int minimumValue);
    void setMaximumValue(int maximumValue);
    void setCurrentValue(int currentValue);

signals:
    void topWidthChanged(int topWidth);
    void backgroundColorChanged(QColor backgroundColor);
    void colorChanged(QColor color);
    void minimumValueChanged(int minimumValue);
    void maximumValueChanged(int maximumValue);
    void currentValueChanged(int currentValue);

private:
    void paint(QPainter *painter);
    int m_topWidth;
    QColor m_backgroundColor;
    QColor m_color;
    int m_minimumValue;
    int m_maximumValue;
    int m_currentValue;
};





#endif // TEMPERATURESCALE_H
