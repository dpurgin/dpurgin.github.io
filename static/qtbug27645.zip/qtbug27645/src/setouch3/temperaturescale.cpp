#include "temperaturescale.h"

#include <QPainter>
#include <QPainterPath>

namespace
{
    void initQml()
    {
        qmlRegisterType< TemperatureScale >(
                    "at.sequality.setouch3.components", 1, 0, "TemperatureScale");
    }

    Q_CONSTRUCTOR_FUNCTION(initQml)
}

TemperatureScale::TemperatureScale(QQuickItem *parent)
    : QQuickPaintedItem (parent),
      m_topWidth(10),
      m_backgroundColor(QColor("lightgrey")),
      m_color(QColor("black")),
      m_minimumValue(0),
      m_maximumValue(100),
      m_currentValue(0)
{

}

int TemperatureScale::topWidth() const
{
    return m_topWidth;
}

QColor TemperatureScale::backgroundColor() const
{
    return m_backgroundColor;
}

QColor TemperatureScale::color() const
{
    return m_color;
}

int TemperatureScale::minimumValue() const
{
    return m_minimumValue;
}

int TemperatureScale::maximumValue() const
{
    return m_maximumValue;
}

int TemperatureScale::currentValue() const
{
    return m_currentValue;
}

void TemperatureScale::setTopWidth(int topWidth)
{
    if (m_topWidth == topWidth)
        return;

    m_topWidth = topWidth;
    update();
    emit topWidthChanged(topWidth);
}

void TemperatureScale::setBackgroundColor(QColor backgroundColor)
{
    if (m_backgroundColor == backgroundColor)
        return;

    m_backgroundColor = backgroundColor;
    update();
    emit backgroundColorChanged(backgroundColor);
}

void TemperatureScale::setColor(QColor color)
{
    if (m_color == color)
        return;

    m_color = color;
    update();
    emit colorChanged(color);
}

void TemperatureScale::setMinimumValue(int minimumValue)
{
    if (m_minimumValue == minimumValue)
        return;

    m_minimumValue = minimumValue;
    update();
    emit minimumValueChanged(minimumValue);
}

void TemperatureScale::setMaximumValue(int maximumValue)
{
    if (m_maximumValue == maximumValue)
        return;

    m_maximumValue = maximumValue;
    update();
    emit maximumValueChanged(maximumValue);
}

void TemperatureScale::setCurrentValue(int currentValue)
{
    if (m_currentValue == currentValue)
        return;

    m_currentValue = currentValue;
    update();
    emit currentValueChanged(currentValue);
}


void TemperatureScale::paint(QPainter *painter)
{
    const int margin = 1;
    const int topRadius = m_topWidth / 2;

    //add top part
    QPainterPath topPath;
    topPath.addRoundedRect(width()/2 - m_topWidth/2, 0, m_topWidth, height() - width()/2, topRadius, topRadius);

    //add bottom part
    QPainterPath bottomPath;
    bottomPath.addEllipse(margin, height() - width(), width()-margin, width()-margin);

    //join top-path and bottom-part
    auto path = topPath.united(bottomPath);

    //filled part
    QPainterPath filledPath;
    double factor = double(m_currentValue - m_minimumValue) / (m_maximumValue - m_minimumValue);
    int fillHeight = int(height() * factor);
    filledPath.addRect(0, height() - fillHeight, width(), fillHeight);

    painter->setRenderHint(QPainter::Antialiasing);

    //paint unfilled part
    painter->fillPath(path.subtracted(filledPath), m_backgroundColor);

    //paint filled part
    painter->fillPath(path.intersected(filledPath), m_color);
}
