#include "rectangle.h"

#include <QPainter>
#include <QPainterPath>

namespace
{
    void initQml()
    {
        qmlRegisterType< Rectangle >(
                    "at.sequality.setouch3.components", 1, 0, "SERectangle");
    }

    Q_CONSTRUCTOR_FUNCTION(initQml)
}

Rectangle::Rectangle(QQuickItem *parent) : QQuickPaintedItem (parent)
{
    m_borderWidth = 0;
    m_topLeftRadius = 0;
    m_topRightRadius = 0;
    m_bottomLeftRadius = 0;
    m_bottomRightRadius = 0;
    m_borderWidth = 0;
}

QColor Rectangle::color() const
{
    return m_color;
}

int Rectangle::topLeftRadius() const
{
    return m_topLeftRadius;
}

int Rectangle::topRightRadius() const
{
    return m_topRightRadius;
}

int Rectangle::bottomLeftRadius() const
{
    return m_bottomLeftRadius;
}

int Rectangle::bottomRightRadius() const
{
    return m_bottomRightRadius;
}

int Rectangle::borderWidth() const
{
    return m_borderWidth;
}

QColor Rectangle::borderColor() const
{
    return m_borderColor;
}

void Rectangle::setColor(QColor color)
{
    if (m_color == color)
        return;

    m_color = color;
    emit colorChanged(color);
    update();
}

void Rectangle::setTopLeftRadius(int topLeftRadius)
{
    if (m_topLeftRadius == topLeftRadius)
        return;

    m_topLeftRadius = topLeftRadius;
    emit topLeftRadiusChanged(topLeftRadius);
    update();
}

void Rectangle::setTopRightRadius(int topRightRadius)
{
    if (m_topRightRadius == topRightRadius)
        return;

    m_topRightRadius = topRightRadius;
    emit topRightRadiusChanged(topRightRadius);
    update();
}

void Rectangle::setBottomLeftRadius(int bottomLeftRadius)
{
    if (m_bottomLeftRadius == bottomLeftRadius)
        return;

    m_bottomLeftRadius = bottomLeftRadius;
    emit bottomLeftRadiusChanged(bottomLeftRadius);
    update();
}

void Rectangle::setBottomRightRadius(int bottomRightRadius)
{
    if (m_bottomRightRadius == bottomRightRadius)
        return;

    m_bottomRightRadius = bottomRightRadius;
    emit bottomRightRadiusChanged(bottomRightRadius);
    update();
}

void Rectangle::setBorderWidth(int borderWidth)
{
    if (m_borderWidth == borderWidth)
        return;

    m_borderWidth = borderWidth;
    emit borderWidthChanged(borderWidth);
    update();
}

void Rectangle::setBorderColor(QColor borderColor)
{
    if (m_borderColor == borderColor)
        return;

    m_borderColor = borderColor;
    emit borderColorChanged(borderColor);
    update();
}

void Rectangle::paint(QPainter *painter)
{
    int margin = m_borderWidth/2;

    int width = painter->device()->width() - margin;
    int height = painter->device()->height() - margin;

    QPainterPath path;

    //start with topleft-corner
    path.moveTo(margin, m_topLeftRadius);
    path.quadTo(QPointF(margin, margin), QPointF(m_topLeftRadius, margin));

    //topright
    path.lineTo(width - m_topRightRadius, margin);
    path.quadTo(QPointF(width, margin), QPointF(width, m_topRightRadius));

    //bottomright
    path.lineTo(width, height - m_bottomRightRadius);
    path.quadTo(QPointF(width, height), QPointF(width-m_bottomRightRadius, height));

    //bottomleft
    path.lineTo(m_bottomLeftRadius, height);
    path.quadTo(QPointF(margin, height), QPointF(margin, height-m_bottomLeftRadius));

    //back to topleft-corner
    path.closeSubpath();

    QPen pen;
    pen.setColor(m_borderColor);
    pen.setWidth(m_borderWidth);
    pen.setCapStyle(Qt::FlatCap);
    pen.setJoinStyle(Qt::MiterJoin);

    painter->setRenderHint(QPainter::Antialiasing);
    painter->setPen(pen);

    painter->fillPath(path, QBrush(QColor(m_color)));

    if(m_borderWidth > 0){
        painter->drawPath(path);
    }
}
