#ifndef RECTANGLE_H
#define RECTANGLE_H

#include <QObject>
#include <QQuickPaintedItem>

class Rectangle : public QQuickPaintedItem
{
    Q_OBJECT
    Q_PROPERTY(QColor color READ color WRITE setColor NOTIFY colorChanged)
    Q_PROPERTY(int topLeftRadius READ topLeftRadius WRITE setTopLeftRadius NOTIFY topLeftRadiusChanged)
    Q_PROPERTY(int topRightRadius READ topRightRadius WRITE setTopRightRadius NOTIFY topRightRadiusChanged)
    Q_PROPERTY(int bottomLeftRadius READ bottomLeftRadius WRITE setBottomLeftRadius NOTIFY bottomLeftRadiusChanged)
    Q_PROPERTY(int bottomRightRadius READ bottomRightRadius WRITE setBottomRightRadius NOTIFY bottomRightRadiusChanged)
    Q_PROPERTY(int borderWidth READ borderWidth WRITE setBorderWidth NOTIFY borderWidthChanged)
    Q_PROPERTY(QColor borderColor READ borderColor WRITE setBorderColor NOTIFY borderColorChanged)

public:
    explicit Rectangle(QQuickItem *parent = 0);
    QColor color() const;
    int topLeftRadius() const;
    int topRightRadius() const;
    int bottomLeftRadius() const;
    int bottomRightRadius() const;
    int borderWidth() const;
    QColor borderColor() const;

public slots:
    void setColor(QColor color);
    void setTopLeftRadius(int topLeftRadius);
    void setTopRightRadius(int topRightRadius);
    void setBottomLeftRadius(int bottomLeftRadius);
    void setBottomRightRadius(int bottomRightRadius);
    void setBorderWidth(int borderWidth);
    void setBorderColor(QColor borderColor);

private:
    QColor m_color;
    int m_topLeftRadius;
    int m_topRightRadius;
    int m_bottomLeftRadius;
    int m_bottomRightRadius;
    int m_borderWidth;
    QColor m_borderColor;
    void paint(QPainter *painter);

signals:
    void colorChanged(QColor color);
    void topLeftRadiusChanged(int topLeftRadius);
    void topRightRadiusChanged(int topRightRadius);
    void bottomLeftRadiusChanged(int bottomLeftRadius);
    void bottomRightRadiusChanged(int bottomRightRadius);
    void borderWidthChanged(int borderWidth);
    void borderColorChanged(QColor borderColor);
};


#endif // RECTANGLE_H
