#ifndef UNITSMODEL_H
#define UNITSMODEL_H

#include "qqmlobjectlistmodel.h"

#include "unitsitem.h"

class UnitsModel : public QQmlObjectListModel< UnitsItem >
{
    Q_OBJECT

public:
    UnitsModel(QObject* parent = nullptr);
    virtual ~UnitsModel();

public slots:
    void populate(const QString& locale);
};

#endif // UNITSMODEL
