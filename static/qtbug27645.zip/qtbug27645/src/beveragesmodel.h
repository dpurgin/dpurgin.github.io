#ifndef BEVERAGESMODEL_H
#define BEVERAGESMODEL_H

#include "qqmlobjectlistmodel.h"
#include "beveragesitem.h"

class BeveragesModel : public QQmlObjectListModel< BeveragesItem >
{
    Q_OBJECT

public:
    BeveragesModel(QObject* parent = nullptr);
    virtual ~BeveragesModel();

public slots:
    void populate(const QString& locale);
};

#endif // BEVERAGESMODEL_H
