#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QDir>

int main(int argc, char* argv[])
{
    QGuiApplication app(argc, argv);
    QQmlApplicationEngine engine;

    engine.addImportPath(QDir::currentPath() + "/qml");
    engine.load("qml/Main.qml");

    return app.exec();
}
