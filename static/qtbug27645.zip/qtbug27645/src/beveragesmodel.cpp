#include "beveragesmodel.h"

#include <QtQml>

#include "helpers.h"

namespace
{
    void initQml()
    {                
        qmlRegisterSingletonType< BeveragesModel >(
            "BottlingPlant.Models",
            1, 0,
            "Beverages",
            [](QQmlEngine*, QJSEngine*) -> QObject*
            {
                return new BeveragesModel();
            }
        );
    }        

    Q_CONSTRUCTOR_FUNCTION(initQml)
}

BeveragesModel::BeveragesModel(QObject* parent)
    : QQmlObjectListModel< BeveragesItem >(parent, "name", "oid")
{
    populate("en");
}

BeveragesModel::~BeveragesModel()
{
}

void BeveragesModel::populate(const QString& locale)
{
    clear();

    BottlingPlant::populateModel< BeveragesItem >(
        this,
        "data/beverages.json",
        &BottlingPlant::dictionaryValidator< QJsonValue::Double >,

        [locale](const QJsonObject& object)
        {
            return new BeveragesItem(
                        object.value("id").toInt(),
                        BottlingPlant::extractLocalizableString(object.value("name"), locale));
        }
    );
}
