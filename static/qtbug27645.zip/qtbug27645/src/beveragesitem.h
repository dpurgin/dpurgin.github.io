#ifndef BEVERAGESITEM_H
#define BEVERAGESITEM_H

#include <QObject>

#include "qqmlhelpers.h"

class BeveragesItem : public QObject
{
    Q_OBJECT

    QML_CONSTANT_PROPERTY(int, oid)
    QML_CONSTANT_PROPERTY(QString, name)

public:
    explicit BeveragesItem(int oid, QString name, QObject* parent = nullptr)
        : QObject(parent),
          m_oid{oid},
          m_name{name}
    {
    }
    virtual ~BeveragesItem()
    {
    }

private:
};

#endif // BEVERAGESITEM_H
