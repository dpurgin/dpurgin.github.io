#include "unitsmodel.h"

#include <QtQml>

#include "helpers.h"

namespace
{
    void initQml()
    {
        qmlRegisterSingletonType< UnitsModel >(
            "BottlingPlant.Models",
            1, 0,
            "Units",
            [](QQmlEngine*, QJSEngine*) -> QObject*
            {
                return new UnitsModel();
            }
        );
    }

    Q_CONSTRUCTOR_FUNCTION(initQml)
}

UnitsModel::UnitsModel(QObject* parent)
    : QQmlObjectListModel< UnitsItem >(parent, "name", "oid")
{
    populate("en");
}

UnitsModel::~UnitsModel()
{
}

void UnitsModel::populate(const QString& locale)
{
    clear();

    BottlingPlant::populateModel< UnitsItem >(
        this,
        "data/units.json",
        &BottlingPlant::dictionaryValidator< QJsonValue::Double >,

        [locale](const QJsonObject& object) {
            return new UnitsItem(
                        object.value("id").toInt(),
                        BottlingPlant::extractLocalizableString(object.value("name"), locale));
        }
    );
}
