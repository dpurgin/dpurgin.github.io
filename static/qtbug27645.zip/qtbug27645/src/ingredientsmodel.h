#ifndef INGREDIENTSMODEL_H
#define INGREDIENTSMODEL_H

#include "qqmlobjectlistmodel.h"
#include "ingredientsitem.h"

class IngredientsModel : public QQmlObjectListModel< IngredientsItem >
{
    Q_OBJECT

public:
    IngredientsModel(QObject* parent = nullptr);
    virtual ~IngredientsModel();

public slots:
    void populate(const QString& locale);
};

#endif // INGREDIENTSMODEL_H
