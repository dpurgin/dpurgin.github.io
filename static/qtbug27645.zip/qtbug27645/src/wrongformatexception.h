#ifndef WRONGFORMATEXCEPTION_H
#define WRONGFORMATEXCEPTION_H

#include "exception.h"

class WrongFormatException : public Exception
{
public:
    WrongFormatException(const QString& what)
        : Exception(what)
    {
    }

    virtual ~WrongFormatException()
    {
    }
};

#endif
