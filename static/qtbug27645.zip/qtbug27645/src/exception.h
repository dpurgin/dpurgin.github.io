#ifndef BOTTLINGPLANT_EXCEPTION_H
#define BOTTLINGPLANT_EXCEPTION_H

#include <exception>
#include <QString>

class Exception : public std::exception
{
public:
    Exception(const QString& what)
        : std::exception(),
          m_what{what}
    {
    }
    virtual ~Exception()
    {
    }

    QString qWhat() const { return m_what; }
    const char* what() const noexcept override { return m_what.toUtf8().data(); }

private:
    QString m_what;
};

#endif // BOTTLINGPLANT_EXCEPTION_H
