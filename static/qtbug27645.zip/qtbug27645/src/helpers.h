#ifndef BOTTLINGPLANT_HELPERS_H
#define BOTTLINGPLANT_HELPERS_H

#include <QFile>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonParseError>
#include <QJsonValue>
#include <QStringBuilder>
#include <QStringList>

#include <functional>

#include "qqmlobjectlistmodel.h"
#include "wrongformatexception.h"

namespace BottlingPlant
{
    QString extractLocalizableString(const QJsonValue& value, const QString& locale);
    QString jsonTypeToString(QJsonValue::Type type);
    bool validateLocalizableString(const QJsonValue& value, QString* errorString);

    template< QJsonValue::Type IdType >
    bool dictionaryValidator(const QJsonObject& itemObject, QString* errorString)
    {
        QStringList errors;

        if (!itemObject.contains("id"))
            errors.push_back("must contain id");
        else if (itemObject.value("id").type() != IdType)
            errors.push_back(QLatin1String("id must be of type: ") % QString::number(IdType));

        if (!itemObject.contains("name"))
            errors.push_back("must contain name");
        else
        {
            QString nameErrorString;

            if (!validateLocalizableString(itemObject.value("name"), &nameErrorString))
                errors.push_back(nameErrorString);
        }

        if (errorString != nullptr)
            *errorString = errors.join(", ");

        return errors.size() == 0;
    }    

    template< class T >
    void populateModel(QQmlObjectListModelBase* model,
                       const QString& fileName,
                       std::function< bool(const QJsonObject&, QString*) > validatorFunction,
                       std::function< T*(const QJsonObject&) > generatorFunction)
    {
        try
        {
            QFile f(fileName);

            if (f.open(QFile::ReadOnly))
            {
                QJsonParseError parseError;

                auto doc = QJsonDocument::fromJson(f.readAll(), &parseError);

                if (parseError.error != QJsonParseError::NoError)
                    throw WrongFormatException(parseError.errorString());

                if (!doc.isArray())
                    throw WrongFormatException("root object must be Array");

                for (const auto& itemValue : doc.array())
                {
                    if (!itemValue.isObject())
                        throw WrongFormatException("Array elements must be of type Object");

                    auto itemObject = itemValue.toObject();

                    QString errorString;

                    if (!validatorFunction(itemObject, &errorString))
                    {
                        throw WrongFormatException(
                                QLatin1String("Error validating item object: ") % errorString);
                    }

                    model->append(generatorFunction(itemObject));
                }
            }
        }
        catch (WrongFormatException& e)
        {
            qCritical() << QLatin1String("Error loading ") % fileName << e.qWhat();
        }
    }

    template< QJsonValue::Type Type, bool Required = true >
    bool validateObjectField(const QJsonObject& object,
                             const QString& field,
                             QStringList* errors = nullptr)
    {
        bool result = false;

        try
        {
            if (Required && !object.contains(field))
            {
                throw WrongFormatException(
                    QString("must contain %1 of type %2").arg(field).arg(jsonTypeToString(Type)));
            }
            else if (object.contains(field) && object.value(field).type() != Type)
            {
                throw WrongFormatException(
                    QString("%1 must be of type %2").arg(field).arg(jsonTypeToString(Type)));
            }

            result = true;
        }
        catch (WrongFormatException& e)
        {
            if (errors)
                errors->append(e.qWhat());

            result = false;
        }

        return result;
    }
}

#endif
