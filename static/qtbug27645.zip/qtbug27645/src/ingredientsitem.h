#ifndef INGREDIENTSITEM_H
#define INGREDIENTSITEM_H

#include <QObject>
#include <QString>

#include "qqmlhelpers.h"

class IngredientsItem : public QObject
{
    Q_OBJECT

    QML_READONLY_PROPERTY(int, oid)
    QML_READONLY_PROPERTY(QString, name)
    QML_READONLY_PROPERTY(int, unitId)
    QML_WRITABLE_PROPERTY(double, quantity)
    QML_READONLY_PROPERTY(double, maxQuantity)

public:
    IngredientsItem(int oid,
                    QString name,
                    int unitId,
                    double quantity,
                    double maxQuantity,
                    QObject* parent = nullptr)
        : QObject(parent),
          m_oid{oid},
          m_name{name},
          m_unitId{unitId},
          m_quantity{quantity},
          m_maxQuantity{maxQuantity}
    {
    }

    virtual ~IngredientsItem()
    {
    }
};

#endif // INGREDIENTSITEM_H
