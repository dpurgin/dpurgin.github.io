#ifndef LOCALESMODEL_H
#define LOCALESMODEL_H

#include "qqmlobjectlistmodel.h"
#include "localesitem.h"

class LocalesModel : public QQmlObjectListModel< LocalesItem >
{
public:
    LocalesModel(QObject* parent = nullptr);
    virtual ~LocalesModel();
};

#endif // LOCALESMODEL_H
