#ifndef LOCALESITEM_H
#define LOCALESITEM_H

#include <QObject>
#include <QString>

#include "qqmlhelpers.h"

class LocalesItem : public QObject
{
    Q_OBJECT

    QML_CONSTANT_PROPERTY(QString, oid)
    QML_CONSTANT_PROPERTY(QString, name)

public:
    explicit LocalesItem(QString id, QString name, QObject* parent = nullptr)
        : QObject(parent),
          m_oid{id},
          m_name{name}
    {
    }

    virtual ~LocalesItem()
    {
    }
};

#endif // LOCALESITEM_H
