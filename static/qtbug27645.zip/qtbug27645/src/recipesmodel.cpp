#include "recipesmodel.h"

#include <QtQml>

#include <algorithm>

#include "helpers.h"

namespace
{
    void initQml()
    {
        qmlRegisterSingletonType< RecipesModel >(
                    "BottlingPlant.Models",
                    1, 0,
                    "Recipes",
                    [](QQmlEngine*, QJSEngine*) -> QObject*
                    {
                        return new RecipesModel();
                    }
        );
    }

    Q_CONSTRUCTOR_FUNCTION(initQml)
}

RecipesModel::RecipesModel(QObject* parent)
    : QQmlObjectListModel< RecipesItem >(parent)
{
    populate("en");
}

RecipesModel::~RecipesModel()
{

}

void RecipesModel::populate(const QString& locale)
{
    Q_UNUSED(locale);

    clear();

    auto validator = [](const QJsonObject& object, QString* errorText)
    {
        QStringList errors;

        auto valid =
            BottlingPlant::validateObjectField< QJsonValue::Double >(
                    object, "beverageId", &errors) &&
            BottlingPlant::validateObjectField< QJsonValue::Array >(
                    object, "ingredients", &errors);

        if (valid)
        {
            QJsonArray ingredients = object.value("ingredients").toArray();

            for (int i = 0; i < ingredients.size(); ++i)
            {
                const auto& itemValue = ingredients[i];

                if (!itemValue.isObject())
                    errors.push_back(QString("ingredients[%i] must be of type Object").arg(i));
                else
                {
                    auto itemObject = ingredients[i].toObject();

                    QStringList itemErrors;

                    BottlingPlant::validateObjectField< QJsonValue::Double >(
                                itemObject, "ingredientId", &itemErrors);
                    BottlingPlant::validateObjectField< QJsonValue::Double >(
                                itemObject, "quantity", &itemErrors);

                    for (auto& item: itemErrors)
                        item.prepend(QString("ingredients[%i]: ").arg(i));
                }

            }
        }

        if (errorText)
            *errorText = errors.join(", ");

        return valid;
    };

    auto generator = [](const QJsonObject& object)
    {
        QScopedPointer< RecipesItem > item(new RecipesItem(object.value("beverageId").toInt()));

        auto* ingredients = item->get_ingredients();

        for (const auto& itemValue : object.value("ingredients").toArray())
        {
            const auto itemObject = itemValue.toObject();

            ingredients->append(
                        new RecipeIngredientsItem(itemObject.value("ingredientId").toInt(),
                                                  itemObject.value("quantity").toDouble()));
        }

        return item.take();
    };

    BottlingPlant::populateModel< RecipesItem >(this, "data/recipes.json", validator, generator);    
}
