#ifndef UNITSITEM_H
#define UNITSITEM_H

#include <QObject>
#include <QString>

#include "qqmlhelpers.h"

class UnitsItem : public QObject
{
    Q_OBJECT

    QML_READONLY_PROPERTY(int, oid)
    QML_READONLY_PROPERTY(QString, name)

public:
    explicit UnitsItem(int oid, QString name, QObject* parent = nullptr)
        : QObject(parent),
          m_oid{oid},
          m_name{name}
    {
    }

    virtual ~UnitsItem()
    {
    }
};

#endif // UNITSITEM_H
