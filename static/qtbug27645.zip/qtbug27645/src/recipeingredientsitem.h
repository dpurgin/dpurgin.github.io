#ifndef RECIPEINGREDIENTSITEM_H
#define RECIPEINGREDIENTSITEM_H

#include "qqmlhelpers.h"

class RecipeIngredientsItem : public QObject
{
    Q_OBJECT

    QML_CONSTANT_PROPERTY(int, ingredientId)
    QML_CONSTANT_PROPERTY(double, quantity)

public:
    explicit RecipeIngredientsItem(int ingredientId, double quantity, QObject* parent = nullptr)
        : QObject(parent),
          m_ingredientId{ingredientId},
          m_quantity{quantity}
    {
    }

    virtual ~RecipeIngredientsItem()
    {
    }

};

#endif // RECIPEIGNREDIENTSITEM_H
