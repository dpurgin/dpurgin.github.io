#include "localesmodel.h"

#include <QtQml>

#include "helpers.h"

namespace
{
    void initQml()
    {
        qmlRegisterSingletonType< LocalesModel >(
            "BottlingPlant.Models",
            1, 0,
            "Locales",
            [](QQmlEngine*, QJSEngine*)->QObject*
            {
                return new LocalesModel();
            }
        );
    }

    Q_CONSTRUCTOR_FUNCTION(initQml)
}

LocalesModel::LocalesModel(QObject* parent)
    : QQmlObjectListModel< LocalesItem >(parent, "name", "oid")
{
    BottlingPlant::populateModel< LocalesItem >(
        this,
        "data/locales.json",
        &BottlingPlant::dictionaryValidator< QJsonValue::String >,

        [](const QJsonObject& object)
        {
            return new LocalesItem(object.value("id").toString(),
                                   object.value("name").toString());
        }
    );
}

LocalesModel::~LocalesModel()
{

}
