#ifndef RECIPESMODEL_H
#define RECIPESMODEL_H

#include "qqmlobjectlistmodel.h"
#include "recipesitem.h"

class RecipesModel : public QQmlObjectListModel< RecipesItem >
{
    Q_OBJECT

public:
    RecipesModel(QObject* parent = nullptr);
    virtual ~RecipesModel();

public slots:
    void populate(const QString& locale);
};

#endif // RECIPESMODEL_H
